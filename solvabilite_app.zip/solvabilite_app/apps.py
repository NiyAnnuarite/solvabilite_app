from django.apps import AppConfig

class SolvabiliteAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'solvabilite_app'
    verbose_name = 'Application Solvabilité II'
